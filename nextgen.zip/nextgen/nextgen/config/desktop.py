from frappe import _

def get_data():
	return [
		{
			"module_name": "Nextgen",
			"type": "module",
			"label": _("Nextgen")
		}
	]
