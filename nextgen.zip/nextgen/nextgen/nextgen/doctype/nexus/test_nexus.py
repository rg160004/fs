# Copyright (c) 2023, e and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestNEXUS(FrappeTestCase):
	pass
